Contributor
===========
Name: Christopher Nguyen
Email: cnguyen115@gmail.com

Name: Kevin Cheng
Email: kevincheng99@csu.fullerton.edu

Programming Language
====================
C++

Execution of Our Program
========================
1. Compilation: make
2. Execution:
./cipher <CIPHER NAME> <KEY> <ENC/DEC> <INPUT FILE> <OUTPUT FILE>

Extra Credit
============
We do not implement the Hi/ell Cipher.

Notes
=====
Chris and I contribute our works to our Git Repository. Please visit out GitHub
providede below at your convenience. Thank you.
https://github.com/kevincheng99/classical-ciphers

After exeuction of Playfaire and Row Transposition cipher, please remove the
following two files, ".playfair_padding_location" and
".rowtransposition_fillers".
